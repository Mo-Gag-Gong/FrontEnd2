package kr.ac.uc.test_2025_05_19_k.model

data class RefreshTokenRequest(
    val refreshToken: String
)