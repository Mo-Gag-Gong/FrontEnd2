// app/src/main/java/kr/ac/uc/test_2025_05_19_k/model/request/GroupNoticeCreateRequest.kt
package kr.ac.uc.test_2025_05_19_k.model.request

data class GroupNoticeCreateRequest(
    val title: String,
    val content: String
)