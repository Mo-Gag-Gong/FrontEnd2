package kr.ac.uc.test_2025_05_19_k.model.request

data class GroupChatCreateRequest(
    val message: String
)