package kr.ac.uc.test_2025_05_19_k.model

data class Interest(
    val interestId: Long,
    val interestName: String
)