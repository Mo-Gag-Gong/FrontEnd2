package kr.ac.uc.test_2025_05_19_k.model

data class GoalDetailResponse(
    val detailId: Long,
    val goalId: Long,
    val description: String,
    val isCompleted: Boolean
)