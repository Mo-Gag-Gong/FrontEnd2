package kr.ac.uc.test_2025_05_19_k.model

data class ProfileRequest(
    val name: String,
    val gender: String,
    val phoneNumber: String,
    val birthYear: Int
)
